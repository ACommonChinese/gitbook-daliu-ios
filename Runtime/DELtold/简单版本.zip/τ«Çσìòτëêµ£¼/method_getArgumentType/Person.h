//
//  Person.h
//  method_getArgumentType
//
//  Created by banma-1118 on 2019/9/24.
//  Copyright © 2019 liuweizhen. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Person : NSObject

- (void)eat:(NSString *)food drink:(NSString *)water;
+ (void)think;

@end

NS_ASSUME_NONNULL_END
